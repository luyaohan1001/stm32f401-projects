This is a simple standalone application example that uses libstlink.
It can be used as a boilerplate for app development.
